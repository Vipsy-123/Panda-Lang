
#pragma once 

class ArenaAllocator {
public:
    // Constructor to the Class ArenaAllocator
    inline explicit ArenaAllocator(size_t bytes) 
        :m_size(bytes)
    {
        m_buffer = static_cast<std::byte*>(malloc(m_size)); // m_buffer is pointer pointing to Memory allocated by malloc.
        m_offset = m_buffer; // m_offset is just the pointer that will help us to keep track of postion where we are currently in allocated memory.
    }

    template <typename T>

    inline T* alloc(){
        void* offset = m_offset;
        m_offset += sizeof(T); // Shift pointer just after memory allocated for current expr 
        return reinterpret_cast<T*>(offset);
    }

    inline ArenaAllocator(const ArenaAllocator& other) = delete; // Overloaded Constructor 

    inline ArenaAllocator operator=(const ArenaAllocator& other) = delete ;

    // Destructor to free allocated memory
    inline ~ArenaAllocator(){
       free(m_buffer);
    }

private:
    size_t m_size;
    std::byte* m_buffer;
    std::byte* m_offset;
};

